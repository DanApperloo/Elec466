README.txt

Elec 466 Project

Dan Apperloo
V00759448


Please note: This project was developed on SystemC 2.2


Thanks.