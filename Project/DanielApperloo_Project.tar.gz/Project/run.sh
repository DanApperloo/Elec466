#!/bin/bash

make clean
make all
./main.x
